Logboek:
Thomas, 15-5-2021, 2 uur, basis + beweging + camera,
Thomas, 15-5-2021, 2 uur, collision
Thomas, 15-5-2021, 3 uur, puzzle + item systeem
Thomas, 15-5-2021, 1,5 uur, Typehints toegevoed + comments + jsconfig voor controle code
Thomas, 15-5-2021, 1 uur, Veranderd naar state manager (overzichtelijker)
Thomas, 15-5-2021, 40 minuten, Camera langzaam/smooth

Thomas, 16-5-2021, 30 minuten, Puzzle meerdere soorten + state veranderd naar room
Thomas, 16-5-2021, 20 minuten, Layers toegevoegd aan renderen
Thomas, 16-5-2021, 1 uur, Wat kamer dingen veranderd voor het renderen
Luuk, 16-5-2021, 5 uur, paint.net begrijpen

Luuk, 18-5-2021, 2 uur, textures tekenen

Luuk, 20-5-2021, 2 uur, textures tekenen
Mick, 20-5-2021, 2 uur, scrummaster bezigheden

Luuk, 22-5-2021, 2 uur, textures tekenen

Thomas, 25-5-2021, 3 uur, Image entity + hud + timer
Thomas, 25-5-2021, 2 uur, Wat test sprites toegevoegd + puzzle en items kleiner
Thomas, 25-5-2021, 4 uur, Uitleggen aan anderen hoe het werkt + praten over de ideëen + kamers maken
Mick, 25-5-2021, 4 uur, Uitleg + praten over de ideëen + kamers maken
Luuk, 25-5-2021, 4 uur, Uitleg + praten over de ideëen + kamers maken
Daan, 25-5-2021, 3 uur + 45 minuten, Uitleg + praten over de ideëen + kamer maken
Rick, 25-5-2021, 2 uur + 45 minuten, Uitleg + praten over de ideëen

Luuk, 26-5-2021, 3 uur, tussentijds tests gedaan op bugs
Mick, 26-5-2021, 3 uur, tussentijds tests gedaan op bugs
Daan, 26-5-2021, 3 uur, tussentijds tests gedaan op bugs

Luuk, 27-5-2021, 3 uur + 30 minuten, Splashscreens designen + splashscreen maken
Rick, 27-5-2021, 4 uur, Splashscreens designen + doolhof designen

Thomas, 28-5-2021, 1 uur, Speler niet afhankelijk van snelheid pc
Mick, 28-5-2021, 4 uur, Speler niet afhankelijk van snelheid pc + teksten schrijven + achtergrondmuziekje zoeken
Daan, 28-5-2021, 4 uur, Speler niet afhankelijk van snelheid pc + teksten schrijven + achtergrondmuziekje zoeken

Mick, 29-5-2021, 4 uur verhaal schrijven en achtergrond geluid uitzoeken
Daan, 29-5-2021, 4 uur verhaal schrijven en achtergrond geluid uitzoeken
Thomas, 29-5-2021, 3 uur, Splashscreen + music
Thomas, 29-5-2021, 1 uur + 30 minuten, Functionaliteit rock
Thomas, 29-5-2021, 3 uur + 30 minuten, Start, gameover, gewonnen schermen

Thomas, 30-5-2021, 4 uur, Crossing the road + kamer verbeteringen
Thomas, 30-5-2021, 30 minuten, Automatisch naar crossing the road camera

Rick, 1-6-2021, 3 uur, tussentijdse tests op bugs + teamoverleg
Mick, 1-6-2021, 1 uur, teamoverleg
Luuk, 1-6-2021, 1uur, teamoverleg
Daan, 1-6-2021, 1 uur, teamoverleg
Thomas, 1-6-2021, 1 uur, teamoverleg

Mick, 2-6-2021, 10 uur, doolhof
Luuk, 2-6-2021, 10 uur, doolhof
Thomas, 2-6-2021, 10 uur, doolhof
Daan, 2-6-2021, 5 uur, doolhof + decoraties

Rick, 5-6-2021, 3 uur, testen in het doolhof
Rick, 6-6-2021, 3 uur, hele spel achter elkaar getest

Daan, 8-6-2021, 6 uur, Daan decoratie doolhof
Thomas, 8-6-2021, 5 uur, daan's decoratie checken en prettier + puzzle stukjes verstoppen

Daan, 9-6-2021, 50 minuten logboek afronden en game testen
Daan, 9-6-2021, 2 uur laatste punten nagekeken en gecommuniceerd met de groep

Totale tijd:
Thomas: 56,17 uur
Luuk: 32 uur
Mick: 31 uur
Daan: 25,58 uur
Rick: 15,75 uur